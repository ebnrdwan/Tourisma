package com.example.android.tourisma;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;

import java.util.ArrayList;


/**
 * A simple {@link Fragment} subclass.
 */
public class Natural extends Fragment {


    public Natural() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment


        View rootview = inflater.inflate(R.layout.list_of_cairo,container,false);

        ArrayList<ListItem> NaturalArrayList = new ArrayList<ListItem>();
        NaturalArrayList.add(new ListItem("Natural Title test",R.string.rasShitan, R.drawable.sahl));
        myAdapter adapter = new myAdapter(getActivity(),NaturalArrayList,R.color.colorAccent);
        ListView NaturalList = (ListView) rootview.findViewById(R.id.Cairolist);
        NaturalList.setAdapter(adapter);

        return rootview;
    }

}
