package com.example.android.tourisma;

import android.app.Activity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * Created by Abdulrhman on 20/09/2016.
 */
public class myAdapter extends ArrayAdapter {
    int color;
    public myAdapter(Activity context, ArrayList <ListItem>myArray, int color) {

        super(context, 0,myArray);
        this.color=color;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
               View itemView = convertView;
        if (itemView==null){
            itemView = LayoutInflater.from(getContext()).inflate(R.layout.listqqitemqqview, parent, false);
        }
        ListItem currentView = (ListItem) getItem(position);
        TextView Title = (TextView) itemView.findViewById(R.id.Title);
        Title.setText(currentView.getTitle());

        TextView desc = (TextView) itemView.findViewById(R.id.description);
        desc.setText(currentView.getDiscription());

        ImageView theimage = (ImageView) itemView.findViewById(R.id.theImage);

        if (currentView.HasImage()){

            theimage.setImageResource(currentView.getImage());
            theimage.setVisibility(View.VISIBLE); }
        else {
            theimage.setVisibility(View.GONE); }

        return itemView;
    }
}
