package com.example.android.tourisma;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;

import java.util.ArrayList;

/**
 * Created by Abdulrhman on 09/10/2016.
 */
public class RandomFragment extends Fragment {
    public RandomFragment() {
        
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View rootview = inflater.inflate(R.layout.list_of_cairo, container, false);

        ArrayList<ListItem> RandomArrayList = new ArrayList<ListItem>();
        RandomArrayList.add(new ListItem("GOUNA",R.string.guna, R.drawable.res10));
        RandomArrayList.add(new ListItem("GOUNA",R.string.guna, R.drawable.guna));
        RandomArrayList.add(new ListItem("TABA", R.string.taba, R.drawable.taba));
        RandomArrayList.add(new ListItem("MARSA ALLAM",R.string.marsaAllam, R.drawable.allam));
        RandomArrayList.add(new ListItem("SAHL HASHEESH", R.string.sahl, R.drawable.sahl));
        RandomArrayList.add(new ListItem("RAS SHITAN", R.string.matrouh, R.drawable.mtrouh));
        RandomArrayList.add(new ListItem("RAS SHITAN", R.string.sokhna, R.drawable.sokhna));
        myAdapter RandomAdapter = new myAdapter(getActivity(), RandomArrayList, R.color.colorAccent);
        ListView RandomList = (ListView) rootview.findViewById(R.id.Cairolist);
        RandomList.setAdapter(RandomAdapter);

        return rootview;
        
        
    }
}
