package com.example.android.tourisma;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;

import java.util.ArrayList;

/**
 * Created by Abdulrhman on 21/09/2016.
 */
public class ResturantsCairo extends Fragment {
    public ResturantsCairo() {
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View rootview = inflater.inflate(R.layout.list_of_cairo, container, false);

        ArrayList<ListItem> VisitesArrayList = new ArrayList<ListItem>();




        VisitesArrayList.add(new ListItem("Sequoia",R.string.res8, R.drawable.res8));
        VisitesArrayList.add(new ListItem("Andrea",R.string.res9, R.drawable.res9));
        VisitesArrayList.add(new ListItem("Piccolo Mondo",R.string.res10, R.drawable.res10));
        VisitesArrayList.add(new ListItem("Sequoia",R.string.res11, R.drawable.res11));
        VisitesArrayList.add(new ListItem("Andrea",R.string.res12, R.drawable.res12));
        VisitesArrayList.add(new ListItem("Sequoia",R.string.res8, R.drawable.res8));
        VisitesArrayList.add(new ListItem("Andrea",R.string.res9, R.drawable.res9));
        VisitesArrayList.add(new ListItem("Piccolo Mondo",R.string.res10, R.drawable.res10));
        VisitesArrayList.add(new ListItem("Sequoia",R.string.res11, R.drawable.res11));
        VisitesArrayList.add(new ListItem("Andrea",R.string.res12, R.drawable.res12));
        VisitesArrayList.add(new ListItem("Sequoia",R.string.res8, R.drawable.res8));
        VisitesArrayList.add(new ListItem("Andrea",R.string.res9, R.drawable.res9));
        VisitesArrayList.add(new ListItem("Piccolo Mondo",R.string.res10, R.drawable.res10));
        VisitesArrayList.add(new ListItem("Sequoia",R.string.res11, R.drawable.res11));
        VisitesArrayList.add(new ListItem("Andrea",R.string.res12, R.drawable.res12));



        myAdapter VisitesAdapter = new myAdapter(getActivity(), VisitesArrayList, R.color.colorAccent);
        ListView VisitesList = (ListView) rootview.findViewById(R.id.Cairolist);
        VisitesList.setAdapter(VisitesAdapter);

        return rootview;

    }
}

