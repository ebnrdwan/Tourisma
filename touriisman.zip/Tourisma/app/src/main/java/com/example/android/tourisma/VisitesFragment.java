package com.example.android.tourisma;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;

import java.util.ArrayList;


public class VisitesFragment extends Fragment {


    public VisitesFragment() {
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View rootview = inflater.inflate(R.layout.list_of_cairo, container, false);

        ArrayList<ListItem> VisitesArrayList = new ArrayList<ListItem>();



        VisitesArrayList.add(new ListItem("GOUNA",R.string.guna, R.drawable.guna));
        VisitesArrayList.add(new ListItem("TABA", R.string.taba, R.drawable.taba));
        VisitesArrayList.add(new ListItem("MARSA ALLAM",R.string.marsaAllam, R.drawable.allam));
        VisitesArrayList.add(new ListItem("SAHL HASHEESH", R.string.sahl, R.drawable.sahl));
        VisitesArrayList.add(new ListItem("RAS SHITAN", R.string.matrouh, R.drawable.mtrouh));
        VisitesArrayList.add(new ListItem("RAS SHITAN", R.string.sokhna, R.drawable.sokhna));







        myAdapter VisitesAdapter = new myAdapter(getActivity(), VisitesArrayList, R.color.colorAccent);
        ListView VisitesList = (ListView) rootview.findViewById(R.id.Cairolist);
        VisitesList.setAdapter(VisitesAdapter);

        return rootview;

    }

}
