package com.example.android.tourisma;

/**
 * Created by Abdulrhman on 20/09/2016.
 */
public class ListItem {

    public ListItem(String title, int discription, int image) {
        this.title = title;
        this.discription = discription;
        this.image = image;
    }

    private String title ;
    private int discription;
   final private int NotHasImage =-1;
    private int image= NotHasImage;

    public void setTitle(String title) {
        this.title = title;
    }

    public String getTitle() {
        return title;
    }

    public void setDiscription(int discription) {
        this.discription = discription;
    }

    public int getDiscription() {
        return discription;
    }

    public void setImage(int image) {
        this.image = image;
    }

    public int getImage() {
        return image;
    }

    public boolean HasImage (){
        return image != NotHasImage ;
    }
}
