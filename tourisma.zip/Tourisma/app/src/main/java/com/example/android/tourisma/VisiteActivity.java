package com.example.android.tourisma;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

public class VisiteActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.list_of_cairo);
        getSupportFragmentManager().beginTransaction()
                .replace(R.id.Cairolist, new VisitesFragment())
                .commit();


//        ArrayList <ListItem> VisitesArrayList = new ArrayList<ListItem>();
//        VisitesArrayList.add(new ListItem("VisistesTitleTest","Visites Description Test", R.mipmap.ic_launcher));
//        VisitesArrayList.add(new ListItem("VisistesTitleTest","Visites Description Test", R.mipmap.ic_launcher));
//        VisitesArrayList.add(new ListItem("VisistesTitleTest","Visites Description Test", R.mipmap.ic_launcher));
//        VisitesArrayList.add(new ListItem("VisistesTitleTest","Visites Description Test", R.mipmap.ic_launcher));
//        VisitesArrayList.add(new ListItem("VisistesTitleTest","Visites Description Test", R.mipmap.ic_launcher));
//
//
//
//        myAdapter VisitesAdapter = new myAdapter(VisiteActivity.this,VisitesArrayList,R.color.colorAccent);
//        ListView VisitesList = (ListView) findViewById(R.id.Cairolist);
//        VisitesList.setAdapter(VisitesAdapter);

    }
}
