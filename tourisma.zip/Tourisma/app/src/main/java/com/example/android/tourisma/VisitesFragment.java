package com.example.android.tourisma;


import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListView;

import java.util.ArrayList;


public class VisitesFragment extends Fragment {



    public VisitesFragment() {}




    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,Bundle savedInstanceState) {

        View rootview = inflater.inflate(R.layout.list_of_cairo,container,false);

        ArrayList<ListItem> VisitesArrayList = new ArrayList<ListItem>();
        VisitesArrayList.add(new ListItem("VisistesTitleTest","Visites Description Test", R.mipmap.ic_launcher));
        VisitesArrayList.add(new ListItem("VisistesTitleTest","Visites Description Test", R.mipmap.ic_launcher));
        VisitesArrayList.add(new ListItem("VisistesTitleTest","Visites Description Test", R.mipmap.ic_launcher));
        VisitesArrayList.add(new ListItem("VisistesTitleTest","Visites Description Test", R.mipmap.ic_launcher));
        VisitesArrayList.add(new ListItem("VisistesTitleTest","Visites Description Test", R.mipmap.ic_launcher));

        myAdapter VisitesAdapter = new myAdapter(getActivity(),VisitesArrayList,R.color.colorAccent);
        ListView VisitesList = (ListView) getActivity().findViewById(R.id.Cairolist);
        VisitesList.setAdapter(VisitesAdapter);

        return rootview;

    }

}
