package com.example.android.tourisma;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.widget.ListView;

import java.util.ArrayList;

/**
 * Created by Abdulrhman on 25/09/2016.
 */
public class NaturalActivity extends AppCompatActivity {

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.list_of_cairo);


        ArrayList <ListItem> NaturalArrayList = new ArrayList<ListItem>();
        NaturalArrayList.add(new ListItem("Natural TestTitle","Natural Test Description",R.mipmap.ic_launcher));

        ListView NaturalListView = (ListView) findViewById(R.id.Cairolist);
        myAdapter NaturalAdapter = new myAdapter(NaturalActivity.this,NaturalArrayList,R.color.colorAccent);
        NaturalListView.setAdapter(NaturalAdapter);
    }
}
