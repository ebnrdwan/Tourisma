package com.example.android.tourisma;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

/**
 * Created by Abdulrhman on 21/09/2016.
 */
public class ResturantsCairo  extends Fragment {
    public ResturantsCairo() {}

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        View rootview = inflater.inflate(R.layout.list_of_cairo,container,false);

//        ArrayList<ListItem> RestArrayList = new ArrayList<ListItem>();
//        RestArrayList.add(new ListItem("TestTitle", "TestDescription", R.drawable.main));
//
//
//        myAdapter adapter = new myAdapter(getActivity(),RestArrayList,R.color.colorAccent);
//        ListView mylist = (ListView) rootview.findViewById(R.id.Resturantlist);
//        mylist.setAdapter(adapter);
        return rootview;


    }
}

