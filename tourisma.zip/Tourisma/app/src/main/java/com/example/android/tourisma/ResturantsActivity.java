package com.example.android.tourisma;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.widget.ListView;

import java.util.ArrayList;

/**
 * Created by Abdulrhman on 22/09/2016.
 */
public class ResturantsActivity extends AppCompatActivity {
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.list_of_cairo);
//        getSupportFragmentManager().beginTransaction()
//                .replace(R.id.Resturantlist, new ResturantsCairo())
//                .commit();
        ArrayList<ListItem> RestArrayList = new ArrayList<ListItem>();
        RestArrayList.add(new ListItem("TestTitle", "TestDescription", R.mipmap.ic_launcher));
        myAdapter adapter = new myAdapter(ResturantsActivity.this,RestArrayList,R.color.colorAccent);
        ListView mylist = (ListView)findViewById(R.id.Cairolist);
        mylist.setAdapter(adapter);

    }
}
